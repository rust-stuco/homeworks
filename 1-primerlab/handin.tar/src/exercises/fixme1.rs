// Make me compile!

#[test]
fn let_x_be() {
    x = 5;
    println!("x has the value {}", x);
}