// Make me compile!

#[test]
fn dont_change_me() {
    let x = 3;
    println!("Number {}", x);
    x = 5; // don't change this line
    println!("Number {}", x);
}
